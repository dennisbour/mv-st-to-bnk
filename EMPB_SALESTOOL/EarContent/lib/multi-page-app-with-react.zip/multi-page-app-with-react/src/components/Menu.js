import React, { Component } from 'react';
import './Menu.css';

const ctx = window.ctx;//'warProject';//

export default class Menu extends Component {
    render() {
        return (
            <ul>
                <li><a href={"/"+ctx+"/react/index.html"}>Home</a></li>
                <li><a href={"/"+ctx+"/react/products/product-1.html"}>Product</a></li>
                <li><a href={"/"+ctx+"/react/contact.html"}>Contact</a></li>
            </ul>
        );
    }
}