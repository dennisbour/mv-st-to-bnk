import React from 'react';
import ReactDOM from 'react-dom';
import Menu from 'components/Menu';

//window.ctx = 'warProject';

ReactDOM.render(<Menu />, document.getElementById('menu'));
