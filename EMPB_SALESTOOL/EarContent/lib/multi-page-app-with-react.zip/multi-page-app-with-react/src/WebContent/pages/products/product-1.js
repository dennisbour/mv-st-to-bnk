import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import Menu from 'components/Menu';

import './product-1.css';
import '../../../../assets/css/bootstrap.min.css';
import productPicture from './product-logo.png';

ReactDOM.render(<Menu />, document.getElementById('menu'));
document.getElementById('product-pic').setAttribute('src', productPicture);

class Products extends Component {
	constructor(props) {
		super(props)
		this.state = {
			countryNames: [],
			error:null,
			loading: false,
		}
		
		this.status = this.status.bind(this)
	}
	
	status(response){
	  if(response.status >= 200 && response.status < 300){
	   return Promise.resolve(response)
	  }else{
	   return Promise.reject(new Error(response.statusText))
	  }
	}
	
	componentWillMount(){
		this.setState({ loading: true })
		fetch('https://restcountries.eu/rest/v1/all')
		.then(status)
		.then(response => response.json())
		.then(json => json.map(country => country.name))
		.then(countryNames => this.setState({ countryNames, loading: false }))
		.catch(error => this.setState({ error }))
	}
	
	render() {
		console.log('countryNames', countryNames);
		const { countryNames, loading, error } = this.state
		return (
		<div className="card">
			{(error) ?
			<p>Problem with API try againg later.</p> :
			(loading) ?
			<p>Loading Country Names...</p> :
			(!countryNames.length) ?
			<p>No country Names</p> :
			<ul>{countryNames.map((x,i) => <li key={i}>{x}</li>)}</ul>}
		</div>
		)
	}
}

ReactDOM.render(<Products />,document.getElementById('products'));
